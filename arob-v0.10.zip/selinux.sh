#!/bin/bash

#selinux.sh

echo "Beta Rooting script for Android on Chrome OS v80+ installed with Brunch"
echo
echo "Version 0.10"
sleep 1
echo
echo "Beta script to inject SuperSU files in an Android Container on Chrome OS v80+"
echo
echo "Part 2 of 2"
sleep 1
echo
echo "There is an SE Linux policy file located at /etc/selinux/arc/policy/policy.30, which can be patched with SuperSU's patching tool."
sleep 1
echo
echo "This script assists with the process."
sleep 1

if [ ! -e /opt/google/containers/android/rootfs/root/system/xbin/su ]; then
  echo
  echo
  echo "Checking for the presence of SuperSU..."
  sleep 1
  echo
  echo "Error!"
  echo "SU binary not found! Unable to continue."
  echo
  echo "You may need to retry script 01Root.sh and check its output for any errors."
  exit 1

else
  echo
  echo "Backing up policy.30 to /etc/selinux/arc/policy/policy.30.old, and to /usr/local/Backup/policy.30.old"

  cp /etc/selinux/arc/policy/policy.30 /etc/selinux/arc/policy/policy.30.old
  cp /etc/selinux/arc/policy/policy.30 /usr/local/Backup/policy.30.old

  echo "Copying policy.30 to /home/chronos/user/Downloads/policy.30 to allow Android access to the file".

  cp -a /etc/selinux/arc/policy/policy.30 /home/chronos/user/Downloads/policy.30
  
  echo
  echo "Opening an Android shell."
  sleep 1
  echo
  echo "Copy and paste the following two su commands into the Android shell."
  echo "Hit Enter after each one."
  echo "If SuperSU is present, the first command should patch the file and display a message indicating this."
  echo
  echo "NOTE: If you are still running not Android 9.0 (Pie), change --sdk=28 to --sdk="your api level" at to the end of the first command."
  sleep 2
  echo
  echo
  echo
  echo
  echo "su -c "supolicy --file /var/run/arc/sdcard/default/emulated/0/Download/policy.30 /var/run/arc/sdcard/default/emulated/0/Download/policy.30_out --sdk=28""
  echo
  echo
  echo "su -c "chmod 0644 /var/run/arc/sdcard/default/emulated/0/Download/policy.30_out""
  echo
  echo
  echo
  echo
  echo "After copy/pasting the commands, leave the Android shell by typing:"
  echo
  echo "exit"
  echo

android-sh

  if [ -e /home/chronos/user/Downloads/policy.30_out ]; then
    echo
    echo "Overwriting policy.30"
    echo "Copying patched policy from /home/chronos/user/Downloads/policy.30_out to /etc/selinux/arc/policy/policy.30"
    
    cp -a /home/chronos/user/Downloads/policy.30_out /etc/selinux/arc/policy/policy.30
    sleep 1
    echo "Done!"
    echo "Please reboot now"
    else
    echo
    echo "Error!"
    echo "Patched SE policy file not found! Unable to complete the procedure."
    echo
    echo "You may need to retry script 01Root.sh and check its output for any errors."
    exit 1
  fi

fi
